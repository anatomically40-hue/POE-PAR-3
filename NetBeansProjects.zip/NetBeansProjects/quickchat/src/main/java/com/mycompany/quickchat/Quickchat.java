/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchat;

import java.io.*;
import java.util.*;

public class Quickchat {

    //logg in //
    static class Login {
        private String username;
        private String password;
        private String cellPhone;

        public Login() {
        }

        public Login(String username, String password, String cellPhone) {
            this.username = username;
            this.password = password;
            this.cellPhone = cellPhone;
        }

        public boolean checkUserName(String username) {
            if (username == null || username.isEmpty()) {
                return false;
            }
            if (!username.contains("_")) {
                return false;
            }
            if (username.length() > 5) {
                return false;
            }
            return true;
        }

        public boolean checkPasswordComplexity(String password) {
            if (password == null || password.length() < 8) {
                return false;
            }
            if (!password.matches(".*[A-Z].*")) {
                return false;
            }
            if (!password.matches(".*[0-9].*")) {
                return false;
            }
            if (!password.matches(".*[!@#$%^&*()_+\\-=\\[\\]{};:'\",.<>?/\\\\|`~].*")) {
                return false;
            }
            return true;
        }

        public boolean checkCellPhoneNumber(String cellPhone) {
            if (cellPhone == null || cellPhone.isEmpty()) {
                return false;
            }

            cellPhone = cellPhone.replaceAll("[\\s-]", "");

            if (cellPhone.startsWith("+27")) {
                cellPhone = cellPhone.substring(1);
            }

            if (cellPhone.startsWith("27")) {
                if (cellPhone.length() != 11) {
                    return false;
                }
                return cellPhone.matches("27\\d{9}");
            } else if (cellPhone.startsWith("0")) {
                if (cellPhone.length() != 10) {
                    return false;
                }
                return cellPhone.matches("0\\d{9}");
            }

            return false;
        }

        public String registerUser(String username, String password, String cellPhone) {
            if (!checkUserName(username)) {
                return "Username requirements not met. Make sure your username has an underscore and is a maximum of five characters long";
            }
            if (!checkPasswordComplexity(password)) {
                return "Please enter a stronger password that includes at least eight characters, one uppercase letter, one numeric digit, and one special character.";
            }
            if (!checkCellPhoneNumber(cellPhone)) {
                return "The cellphone number provided is invalid or missing an international dialing code. Please verify the number and try again.";
            }

            this.username = username;
            this.password = password;
            this.cellPhone = cellPhone;
            return " WARM Welcome " + username + ", <user last name> please chech for anyupdades on olay store .";
        }

        public boolean loginUser(String username, String password) {
            return this.username != null && this.username.equals(username) && this.password.equals(password);
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getCellPhone() {
            return cellPhone;
        }

        public void setCellPhone(String cellPhone) {
            this.cellPhone = cellPhone;
        }
    }

    //MASSAGE//
    static class Message {
        private String messageID;
        private String recipient;
        private String messageContent;
        private String messageHash;
        private int numMessagesSent;
        private static int totalMessagesSent = 0;

        public Message() {
            this.messageID = generateMessageID();
            this.numMessagesSent = 0;
        }

        public Message(String recipient, String messageContent) {
            this.messageID = generateMessageID();
            this.recipient = recipient;
            this.messageContent = messageContent;
            this.numMessagesSent = 0;
        }

        private String generateMessageID() {
            Random random = new Random();
            long id = 1000000000L + random.nextLong(9000000000L);
            return String.valueOf(id);
        }

        public boolean checkMessageID() {
            return messageID != null && messageID.length() <= 10;
        }

        public boolean checkRecipientCell(String cellPhone) {
            Login login = new Login();
            return login.checkCellPhoneNumber(cellPhone);
        }

        public boolean validateMessageContent() {
            if (messageContent == null) {
                return false;
            }
            return messageContent.length() <= 250;
        }

        public String createMessageHash() {
            if (messageContent == null || messageContent.isEmpty()) {
                return "";
            }

            String[] words = messageContent.trim().split("\\s+");
            String firstWord = words.length > 0 ? words[0].toUpperCase() : "";
            String lastWord = words.length > 1 ? words[words.length - 1].toUpperCase() : firstWord;

            String hashInput = messageID.substring(0, 2) + ":" + numMessagesSent + ":" + firstWord + ":" + lastWord;
            this.messageHash = hashInput;
            return hashInput;
        }

        public String sendMessage(String choice) {
            if (choice.equals("1") || choice.equalsIgnoreCase("Send Message")) {
                if (!validateMessageContent()) {
                    return "Message exceeds 250 characters by X [enter number here]; please reduce the size.";
                }
                if (!checkRecipientCell(recipient)) {
                    return "Cell phone number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
                }
                numMessagesSent++;
                totalMessagesSent++;
                return "Message successfully sent";
            } else if (choice.equals("0") || choice.equalsIgnoreCase("Disregard Message")) {
                return "Press 0 to delete the message";
            } else if (choice.equals("2") || choice.equalsIgnoreCase("Store Message")) {
                return "Message successfully stored";
            }
            return "";
        }

        public String getMessageDetails() {
            return messageID + "|" + messageHash + "|" + recipient + "|" + messageContent;
        }

        public String getMessageID() {
            return messageID;
        }

        public void setMessageID(String messageID) {
            this.messageID = messageID;
        }

        public String getRecipient() {
            return recipient;
        }

        public void setRecipient(String recipient) {
            this.recipient = recipient;
        }

        public String getMessageContent() {
            return messageContent;
        }

        public void setMessageContent(String messageContent) {
            this.messageContent = messageContent;
        }

        public String getMessageHash() {
            return messageHash;
        }

        public void setMessageHash(String messageHash) {
            this.messageHash = messageHash;
        }

        public int getNumMessagesSent() {
            return numMessagesSent;
        }

        public void setNumMessagesSent(int numMessagesSent) {
            this.numMessagesSent = numMessagesSent;
        }

        public static int getTotalMessagesSent() {
            return totalMessagesSent;
        }

        public static void setTotalMessagesSent(int total) {
            totalMessagesSent = total;
        }

        @Override
        public String toString() {
            return "Message{" +
                    "messageID='" + messageID + '\'' +
                    ", recipient='" + recipient + '\'' +
                    ", messageContent='" + messageContent + '\'' +
                    ", messageHash='" + messageHash + '\'' +
                    '}';
        }
    }

    //MASSAGE STORAGE 
    static class MessageStorage {
        private static final String MESSAGES_FILE = "messages.json";
        private List<Map<String, String>> messages;

        public MessageStorage() {
            this.messages = new ArrayList<>();
            loadMessages();
        }

        public void saveMessage(Message message) {
            Map<String, String> msgMap = new HashMap<>();
            msgMap.put("messageID", message.getMessageID());
            msgMap.put("recipient", message.getRecipient());
            msgMap.put("messageContent", message.getMessageContent());
            msgMap.put("messageHash", message.getMessageHash());
            msgMap.put("numMessagesSent", String.valueOf(message.getNumMessagesSent()));

            messages.add(msgMap);
            writeToFile();
        }

        private void loadMessages() {
            File file = new File(MESSAGES_FILE);
            if (!file.exists()) {
                return;
            }

            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                parseJSON(sb.toString());
            } catch (IOException e) {
                System.out.println("Error reading messages file: " + e.getMessage());
            }
        }

        private void writeToFile() {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(MESSAGES_FILE))) {
                writer.write("[\n");
                for (int i = 0; i < messages.size(); i++) {
                    Map<String, String> msg = messages.get(i);
                    writer.write("  {\n");
                    writer.write("    \"messageID\": \"" + msg.get("messageID") + "\",\n");
                    writer.write("    \"recipient\": \"" + msg.get("recipient") + "\",\n");
                    writer.write("    \"messageContent\": \"" + msg.get("messageContent") + "\",\n");
                    writer.write("    \"messageHash\": \"" + msg.get("messageHash") + "\",\n");
                    writer.write("    \"numMessagesSent\": " + msg.get("numMessagesSent") + "\n");
                    writer.write("  }");
                    if (i < messages.size() - 1) {
                        writer.write(",");
                    }
                    writer.write("\n");
                }
                writer.write("]\n");
            } catch (IOException e) {
                System.out.println("Error writing to messages file: " + e.getMessage());
            }
        }

        private void parseJSON(String json) {
            json = json.trim();
            if (!json.startsWith("[") || !json.endsWith("]")) {
                return;
            }

            json = json.substring(1, json.length() - 1);
            String[] objects = json.split("\\},\\s*\\{");

            for (String obj : objects) {
                obj = obj.replaceAll("^\\{|\\}$", "").trim();
                if (obj.isEmpty()) continue;

                Map<String, String> msgMap = new HashMap<>();
                String[] pairs = obj.split(",");

                for (String pair : pairs) {
                    String[] keyValue = pair.split(":", 2);
                    if (keyValue.length == 2) {
                        String key = keyValue[0].trim().replaceAll("\"", "");
                        String value = keyValue[1].trim().replaceAll("\"", "");
                        msgMap.put(key, value);
                    }
                }

                if (!msgMap.isEmpty()) {
                    messages.add(msgMap);
                }
            }
        }

        public List<Map<String, String>> getAllMessages() {
            return messages;
        }

        public void displayAllMessages() {
            if (messages.isEmpty()) {
                System.out.println("No messages.");
                return;
            }

            System.out.println("\n===All Messages ===");
            for (Map<String, String> msg : messages) {
                System.out.println("Message ID: " + msg.get("messageID"));
                System.out.println("Message Hash: " + msg.get("messageHash"));
                System.out.println("Recipient: " + msg.get("recipient"));
                System.out.println("Message: " + msg.get("messageContent"));
                System.out.println("---");
            }
        }

        public void generateTaskReport() {
            System.out.println("\n TASK REPORT");
            System.out.println("Total Messages Stored: " + messages.size());
            
            if (messages.isEmpty()) {
                System.out.println("No messages in storage.");
            } else {
                System.out.println("\nDetailed Message Report:");
                System.out.println("--------");
                int count = 1;
                for (Map<String, String> msg : messages) {
                    System.out.println("\nMessage #" + count);
                    System.out.println("  ID: " + msg.get("messageID"));
                    System.out.println("  Hash: " + msg.get("messageHash"));
                    System.out.println("  Recipient: " + msg.get("recipient"));
                    System.out.println("  Content: " + msg.get("messageContent"));
                    System.out.println("  Sent Count: " + msg.get("numMessagesSent"));
                    count++;
                }
            }
            System.out.println("\n=========================================");
        }

        public int getMessageCount() {
            return messages.size();
        }

        public void exportToFile(String filename) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
                writer.write("QuickChat Message Report\n");
                writer.write("Generated: " + new Date() + "\n");
                writer.write("=======================================\n\n");
                writer.write("Total Messages: " + messages.size() + "\n\n");

                int count = 1;
                for (Map<String, String> msg : messages) {
                    writer.write("Message #" + count + "\n");
                    writer.write("  Message ID: " + msg.get("messageID") + "\n");
                    writer.write("  Message Hash: " + msg.get("messageHash") + "\n");
                    writer.write("  Recipient: " + msg.get("recipient") + "\n");
                    writer.write("  Content: " + msg.get("messageContent") + "\n");
                    writer.write("  Sent: " + msg.get("numMessagesSent") + "\n");
                    writer.write("\n");
                    count++;
                }
                System.out.println("Report exported to: " + filename);
            } catch (IOException e) {
                System.out.println("Error exporting report: " + e.getMessage());
            }
        }
    }

    // MAIN APPLICATION 
    private Login currentUser;
    private MessageStorage storage;
    private Scanner scanner;
    private int numMessagesToEnter;
    private int messagesEntered;

    public Quickchat() {
        this.currentUser = null;
        this.storage = new MessageStorage();
        this.scanner = new Scanner(System.in);
        this.numMessagesToEnter = 0;
        this.messagesEntered = 0;
    }

    public void start() {
        System.out.println("\n===== Welcome to QuickChat =====\n");

        while (true) {
            if (currentUser == null) {
                displayAuthMenu();
            } else {
                displayMainMenu();
            }
        }
    }

    private void displayAuthMenu() {
        System.out.println("\n1. Register");
        System.out.println("2. Login");
        System.out.println("3. Exit");
        System.out.print("Select an option: ");

        String choice = scanner.nextLine().trim();

        switch (choice) {
            case "1":
                registerUser();
                break;
            case "2":
                loginUser();
                break;
            case "3":
                System.out.println("Goodbye!");
                System.exit(0);
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private void registerUser() {
        System.out.println("\n--- Registration ---");

        System.out.print("Enter username (format: must contain '_' and max 5 chars): ");
        String username = scanner.nextLine().trim();

        System.out.print("Enter password (min 8 chars, 1 capital, 1 number, 1 special char): ");
        String password = scanner.nextLine().trim();

        System.out.print("Enter South African cell phone number (format: +27... or 0...): ");
        String cellPhone = scanner.nextLine().trim();

        Login newUser = new Login();
        String result = newUser.registerUser(username, password, cellPhone);
        System.out.println(result);

        if (result.contains("it is great to see you")) {
            this.currentUser = newUser;
            askForMessageCount();
        }
    }

    private void loginUser() {
        System.out.println("\n--- Login ---");

        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();

        System.out.print("Enter password: ");
        String password = scanner.nextLine().trim();

        Login tempUser = new Login(username, password, "");
        if (tempUser.loginUser(username, password)) {
            System.out.println("Welcome " + username + ", <user last name> it is great to see you again.");
            this.currentUser = tempUser;
            askForMessageCount();
        } else {
            System.out.println("Username or password incorrect, please try again.");
        }
    }

    private void askForMessageCount() {
        System.out.print("\nHow many messages do you want to send? ");
        try {
            this.numMessagesToEnter = Integer.parseInt(scanner.nextLine().trim());
            this.messagesEntered = 0;
        } catch (NumberFormatException e) {
            System.out.println("Invalid number. Setting to 1 message.");
            this.numMessagesToEnter = 1;
            this.messagesEntered = 0;
        }
    }

    private void displayMainMenu() {
        System.out.println("\n=== Welcome to QuickChat ===");
        System.out.println("1. Send Messages");
        System.out.println("2. View Message History");
        System.out.println("3. Generate Task Report");
        System.out.println("4. Export Report to File");
        System.out.println("5. Quit");
        System.out.print("Select an option: ");

        String choice = scanner.nextLine().trim();

        switch (choice) {
            case "1":
                sendMessages();
                break;
            case "2":
                storage.displayAllMessages();
                break;
            case "3":
                storage.generateTaskReport();
                break;
            case "4":
                System.out.print("Enter filename for export (e.g., report.txt): ");
                String filename = scanner.nextLine().trim();
                storage.exportToFile(filename);
                break;
            case "5":
                System.out.println("Exiting QuickChat. Goodbye!");
                System.exit(0);
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private void sendMessages() {
        System.out.println("\n=== Send Messages ===");

        while (messagesEntered < numMessagesToEnter) {
            System.out.println("\nMessage " + (messagesEntered + 1) + " of " + numMessagesToEnter);

            System.out.print("Enter recipient cell phone number: ");
            String recipient = scanner.nextLine().trim();

            System.out.print("Enter message (max 250 characters): ");
            String content = scanner.nextLine().trim();

            Message message = new Message(recipient, content);

            if (!message.checkMessageID()) {
                System.out.println("Error: Invalid message ID.");
                continue;
            }

            if (!message.checkRecipientCell(recipient)) {
                System.out.println("Cell phone number is incorrectly formatted or does not contain an international code; please correct the number and try again.");
                continue;
            }

            if (!message.validateMessageContent()) {
                int excess = message.getMessageContent().length() - 250;
                System.out.println("Message exceeds 250 characters by " + excess + "; please reduce the size.");
                continue;
            }

            message.createMessageHash();

            System.out.println("\nMessage ready:");
            System.out.println("ID: " + message.getMessageID());
            System.out.println("Hash: " + message.getMessageHash());
            System.out.println("To: " + recipient);
            System.out.println("Content: " + content);

            System.out.println("\n1) Send Message");
            System.out.println("2) Store Message");
            System.out.println("0) Disregard Message");
            System.out.print("Select option: ");

            String option = scanner.nextLine().trim();

            if (option.equals("1")) {
                System.out.println("Message successfully sent.");
                message.setNumMessagesSent(messagesEntered + 1);
                storage.saveMessage(message);
                messagesEntered++;
            } else if (option.equals("2")) {
                System.out.println("Message successfully stored.");
                message.setNumMessagesSent(messagesEntered + 1);
                storage.saveMessage(message);
                messagesEntered++;
            } else if (option.equals("0")) {
                System.out.println("Press 0 to delete the message.");
                System.out.println("Message discarded.");
                messagesEntered++;
            } else {
                System.out.println("Invalid option.");
            }
        }

        System.out.println("\n=== Messages Summary ===");
        storage.displayAllMessages();
        System.out.println("Total messages sent: " + storage.getMessageCount());

        this.messagesEntered = 0;
        this.numMessagesToEnter = 0;
        this.currentUser = null;
        System.out.println("\nYou have been logged out.");
    }

    public static void main(String[] args) {
        Quickchat app = new Quickchat();
        app.start();
    }
}
